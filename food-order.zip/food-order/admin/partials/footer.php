<div class="footer">
            <div class="wrapper">
            <p class="text-center"> 2021 All rights reserved, Wow Foods. Developed By - <a class="panda" href="#">Panda</a></p>
            </div>
        </div>  
    </body>
</html>