<?php
if(!isset($_SESSION['user']))
{
    $_SESSION['no-login-message'] = "<div class='text-center'>Please Login To Acess Admin Panel.</div>";
    header("location:".SITEURL.'admin/login.php');
}
?>